#include<iostream>
using namespace std;
void main( )
{
	int a=10;
	int *p;
	p=&a;
	cout<<" a    => "<< a <<"\n";	
	cout<<" &a   => "<< &a <<"\n";
	cout<<" p    => "<< p <<"\n";	
	cout<<" *p   => "<< *p <<"\n";	
}
