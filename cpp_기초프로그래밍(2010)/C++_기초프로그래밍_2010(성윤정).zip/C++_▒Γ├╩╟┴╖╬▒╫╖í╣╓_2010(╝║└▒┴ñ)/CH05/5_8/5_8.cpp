#include<iostream>
using namespace std;
void swap(int *pa, int *pb);
void main( )
{
	int a=10, b=20;
	cout<<" a => "<< &a <<"   b => "<< &b <<"\n";
	swap(&a, &b);
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
}
void swap(int *pa, int *pb)
{
	int t;
	t=*pa;
	*pa=*pb;
	*pb=t;
}
