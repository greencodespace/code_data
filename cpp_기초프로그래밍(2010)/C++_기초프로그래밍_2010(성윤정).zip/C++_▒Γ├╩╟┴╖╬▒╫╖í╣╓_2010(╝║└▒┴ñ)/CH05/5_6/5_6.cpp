#include<iostream>
using namespace std;
void main( )
{
	int a=10, b=20;
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
	int t;
	t=a;
	a=b;
	b=t;
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
}
