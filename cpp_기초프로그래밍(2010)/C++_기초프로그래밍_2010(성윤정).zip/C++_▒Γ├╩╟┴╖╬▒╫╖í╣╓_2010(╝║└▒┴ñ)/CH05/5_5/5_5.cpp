#include<iostream>
using namespace std;
void main( )
{
	int a=10, b=20;
	int *p=&a;
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
	cout<<" *p=> "<< *p <<"\n";	
    b=*p;
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
	cout<<" *p=> "<< *p <<"\n";
	*p=30;
	cout<<" a => "<< a <<"   b => "<< b <<"\n";
	cout<<" *p=> "<< *p <<"\n";
}
