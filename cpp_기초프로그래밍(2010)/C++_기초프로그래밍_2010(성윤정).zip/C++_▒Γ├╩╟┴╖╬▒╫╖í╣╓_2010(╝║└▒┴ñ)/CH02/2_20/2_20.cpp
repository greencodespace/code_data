 #include<iostream>
  using namespace std; 
  void main( )
  { 
    int a , b = 2;
   
    a = 10; a += b; cout << " a = " << a<< "\n";
    a = 10; a -= b; cout << " a = " << a<< "\n";
    a = 10; a *= b; cout << " a = " << a<< "\n";
    a = 10; a /= b; cout << " a = " << a << "\n";
    a = 10; a %= b; cout << " a = " << a << "\n";
  }
