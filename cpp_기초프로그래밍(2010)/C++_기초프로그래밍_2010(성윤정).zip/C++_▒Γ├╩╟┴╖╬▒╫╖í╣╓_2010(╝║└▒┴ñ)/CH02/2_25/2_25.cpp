 #include <iostream>
 #include <iomanip>
 using namespace std; 

 void main()
 {
    int a = 3, b = 5;
    bool istrue;
    istrue = a = b;
    cout<<" a�� b�� �����ϱ�? "  << istrue << "\n";
 }