 #include <iostream>
 using namespace std; 
 void main()
 {
    cout << 'A' <<"\t";
	cout << (int) 'A' <<"\n";
    cout << 'a' <<"\t";
	cout << (int) 'a' <<"\n";
	cout << '0' <<"\t";
	cout << (int) '0' <<"\n";
	cout << "------------------------\n";
	cout << 'A'+1 <<"\t";
	cout << (char) ('A'+1) <<"\n";
 }
