  #include<iostream>
  using namespace std; 
  void main( )
  {
	int a=10, b=10;
	cout<<"  Before =======> a : "<<a<<"     b : "<<b<<"\n";
	cout<<"  a++   ========> a : "<<a++<<"\n";		//	�� ��
	cout<<"  ++b   ========> b : "<<++b<<"\n";		//	�� ��
	cout<<"  After ========> a : "<<a<<"     b : "<<b<<"\n";		
 }                                                                          
