 #include <iostream>
 using namespace std; 
 void main()
 {
     bool b1 = true, b2 = false;
	 
     cout <<" b1(true)  = " << b1 <<"\n";
     cout <<" b2(false) = " << b2 <<"\n";

     bool c = -1, d = 0;  
     cout <<" c(-1) = " << c <<"\n";
     cout <<" d(0)  = " << d <<"\n";
 }