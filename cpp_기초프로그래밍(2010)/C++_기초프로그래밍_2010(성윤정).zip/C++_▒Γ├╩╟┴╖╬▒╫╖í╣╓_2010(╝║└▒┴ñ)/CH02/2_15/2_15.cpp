 #include <iostream>
 using namespace std; 
 void main()
 {
   cout<<2/4<<"\n";
   cout<<2/4.0<<"\n";
   cout<<2.0/4.0<<"\n";
   cout<<2%4<<"\n";
 //  cout<<2.0%4.0<<"\n";
 }

