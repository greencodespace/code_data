 #include <iostream>
 using namespace std; 
 void main()
 {
     int a = 8, b = 3;
     cout<<a<<" + "<<b<<" = "<<a+b<<"\n";
 	cout<<a<<" - "<<b<<" = "<<a-b<<"\n";
 	cout<<a<<" * "<<b<<" = "<<a*b<<"\n";
 	cout<<a<<" / "<<b<<" = "<<a/b<<"\n";
 	cout<<a<<" % "<<b<<" = "<<a%b<<"\n";
 }
