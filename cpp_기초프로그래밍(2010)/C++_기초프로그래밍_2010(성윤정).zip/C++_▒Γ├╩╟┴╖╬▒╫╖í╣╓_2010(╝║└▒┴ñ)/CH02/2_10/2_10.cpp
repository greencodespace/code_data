 #include <iostream>
 using namespace std; 
 void main()
 {
    cout<<"  \\n  ==> " <<"\n"<<"\n";
    cout<<"  \\t  ==> " <<"\t"<<"�Ǵ�������\n";
    cout<<"  \\b  ==> " <<"123"<<"\b"<<"45\n";
    cout<<"  \\\\  ==> " << "\\"<<"\n";
    cout<<"  \\\'  ==> " << "\'"<<"\n";
    cout<<"  \\\"  ==> " << "\""<<"\n";

 }
