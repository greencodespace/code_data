#include<iostream>
  using namespace std; 
 void main( )
 {
	 short int x = 15;

    cout << "x << 2  : " << (x << 2) << "\n";
    cout << "x >> 2  : " << (x >> 2) << "\n";
 }
