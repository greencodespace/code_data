 #include<iostream>
  using namespace std; 
 void main( )
 {
	int a=23;
	float b=3.5f;
	char c='A';
	cout<<"\n <====== Data Type ========>";
	cout<<"\n int size    : "<<sizeof(int);
	cout<<"\n long size   : "<<sizeof(long);
	cout<<"\n float size  : "<<sizeof(float);
	cout<<"\n double size : "<<sizeof(double);
	cout<<"\n char size   : "<<sizeof(char);

	cout<<"\n <====== Variable ========>";
	cout<<"\n int size    : "<<sizeof(a);
	cout<<"\n float size  : "<<sizeof(b);
	cout<<"\n char size   : "<<sizeof(c);

	cout<<"\n <=======Constant ========>";
	cout<<"\n int size    : "<<sizeof(23);
	cout<<"\n double size : "<<sizeof(3.5);
	cout<<"\n float size  : "<<sizeof(3.5f);
	cout<<"\n char size   : "<<sizeof('A');
	cout<<"\n string size : "<<sizeof("Apple")<<"\n";
}                                                       
