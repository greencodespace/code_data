#include<iostream>
using namespace std; 
void main( )
{
  double a=1.0;
  double b=2.0;
  int  res01 = a % b;
  //   int  res01 = (int)a % (int)b;

  cout<<a<<"%"<<b<<"="<<res01<<endl;
}
