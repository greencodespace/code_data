 #include <iostream>
 using namespace std; 
 void main()
 {
  char ch1 = 'A', ch2 = 'B';
  cout << ch1 << "\t" << ch2 << "\n";

  int i = ch1, j = ch2;
  cout << i << "\t" << j << "\n";
 }
