 #include <iostream>
 using namespace std; 
 void main()
 {
	 bool istrue;

	 istrue = true  && true;
     cout<< "  true  && true  = " << istrue << "\n";

 	 istrue = true  && false;
     cout<< "  true  && false = " << istrue << "\n";

	 istrue = false || false;
     cout<< "  false || false = " << istrue << "\n";

   	 istrue = true  || false;
     cout<< "  true  || false = " << istrue << "\n";

	 istrue = ! true;
     cout<< "  ! true = " << istrue << "\n";
 }
