#include<iostream>
  using namespace std; 
 void main( )
 {
     short x = 10, y = 6 ;
     cout << " x & y  : " << (x & y) << "\n";
     cout << " x | y  : " << (x | y) << "\n";
     cout << " x ^ y  : " << (x ^ y) << "\n";
     cout << " ~x     : " << (~x) << "\n";
 }