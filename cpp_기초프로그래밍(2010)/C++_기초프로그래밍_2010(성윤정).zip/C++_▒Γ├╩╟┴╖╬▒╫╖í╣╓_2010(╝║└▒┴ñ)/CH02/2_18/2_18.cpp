
 #include <iostream>
 using namespace std; 
 void main()
 {
	 int num=85;

	 bool istrue;

	 istrue = ! num == 70;
     cout<< " ! num == 70 = " << istrue << "\n";

	 istrue = ! (num == 70);
     cout<< " ! (num == 70) = " << istrue << "\n";

	 istrue = num >= 80 && num < 90; 
     cout<< " num >= 80 && num < 90  = " << istrue << "\n";

	 num=60;

	 istrue = num >= 80 && num < 90; 
     cout<< " num >= 80 && num < 90 = " << istrue << "\n";

	 istrue = num >= 90 || num < 80;
     cout<< " num >= 90 || num < 80 = " << istrue << "\n";

     num=85;
   	 istrue = num >= 90 || num < 80;
     cout<< " num >= 90 || num < 80 = " << istrue << "\n";
 }





