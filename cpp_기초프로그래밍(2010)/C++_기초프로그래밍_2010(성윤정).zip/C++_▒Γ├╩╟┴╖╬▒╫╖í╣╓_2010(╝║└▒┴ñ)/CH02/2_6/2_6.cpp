 #include <iostream>
 using namespace std; 
 void main()
 {
    short m_short = 40000;
    cout << "m_short = 40000 �϶� m_short = " << m_short <<"\n";
    m_short = 20000;
    cout << "m_short = 20000 �϶� m_short = " << m_short <<"\n";
    int m_int = 40000;
    cout << "m_int = 40000 �϶� m_int= " << m_int <<"\n";
 }
