#include<iostream>
using namespace std;
#define ROW		3
#define COL		4
void main()
{
	int a[ROW][COL] = {	{90, 85, 95, 100},
				{75, 95, 80, 90},
				{90, 80, 70, 60}
			  };

	cout<< "\n a     => "  << a;
	cout<< "\n *a    => "  << *a;
	cout<< "\n **a   => "  << **a;
	cout<< "\n a + 1 => " << a + 1;
	cout<< "\n a + 2 => " << a + 2;
	cout<< "\n";
}
