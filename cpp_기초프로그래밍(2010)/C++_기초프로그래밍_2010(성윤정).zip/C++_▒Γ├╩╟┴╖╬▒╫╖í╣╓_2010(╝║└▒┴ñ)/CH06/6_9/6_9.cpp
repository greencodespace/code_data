#include<iostream>
using namespace std;
void main()
{
	int a[5] = {10,20,30,40,50};
	cout<<" a   => "<<a   <<"  &a[0]=> "<<&a[0]<<"\n" ;
	cout<<" a+1 => "<<a+1 <<"  &a[1]=> "<<&a[1]<<"\n" ;
	cout<<" a+2 => "<<a+2 <<"  &a[2]=> "<<&a[2]<<"\n" ;
	cout<<" a+3 => "<<a+3 <<"  &a[3]=> "<<&a[3]<<"\n" ;
	cout<<" a+4 => "<<a+4 <<"  &a[4]=> "<<&a[4]<<"\n" ;
}
