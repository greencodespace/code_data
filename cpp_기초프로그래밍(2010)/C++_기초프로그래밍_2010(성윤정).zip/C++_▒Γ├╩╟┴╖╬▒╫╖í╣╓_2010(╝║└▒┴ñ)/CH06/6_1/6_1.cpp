#include<iostream>
using namespace std; 
void main()
{
	int a[5]; 
	
	a[0]=50;	    
	a[1]=100;
	a[2]=150;
	a[3]=200;
	a[4]=250;

    for(int i=0; i<5; i++)
	  cout << a[i] << "    " ;
    cout << "\n";
}
