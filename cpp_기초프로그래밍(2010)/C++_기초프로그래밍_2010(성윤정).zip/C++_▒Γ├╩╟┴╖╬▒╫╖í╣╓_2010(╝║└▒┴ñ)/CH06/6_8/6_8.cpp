#include<iostream>
using namespace std; 
void main()
{
   int a[5] = {10, 20, 30, 40, 50};
  
   cout << "  a =      " << a << "\n";
   cout << "  &a[0] =  " << &a[0] << "\n";
}
