#include<iostream>
using namespace std; 
void main()
{
	int a[5]={85, 90, 75, 100, 95};	    
    int tot=0;
	double avg;
    int i;

    for(i=0; i<5; i++)
		tot+=a[i];
    
	avg = (double)tot/5.0;
	
	cout << "���� = " << tot <<"\n";
	cout << "��� = " << avg <<"\n";
}
