#include<iostream>
using namespace std;
void main()
{
   int     i= 5;
   double  d= 10.6;
   d = i;
   i = d;
   char c;
   c=d;
}
