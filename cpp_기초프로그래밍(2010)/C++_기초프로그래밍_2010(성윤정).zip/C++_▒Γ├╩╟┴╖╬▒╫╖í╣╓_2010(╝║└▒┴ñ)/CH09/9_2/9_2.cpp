#include<iostream>
using namespace std;
class  Complex 	
{
 private :
	int 	real;	
	int 	image;
 public :
	Complex(int real=0, int image=0);
	void ShowComplex( ) const;
};

/*
Complex::Complex(int real, int image) 
{ 
  real=real;
  image=image;
}
*/

Complex::Complex(int real, int image) 
{ 
  this->real=real;
  this->image=image;
}

void Complex::ShowComplex( ) const
{
	cout<<"( "<< this->real <<" + "<< this->image <<"i )"<<endl ;
}

void main( )
{
	Complex  x(10,20);
	x.ShowComplex( );
}

