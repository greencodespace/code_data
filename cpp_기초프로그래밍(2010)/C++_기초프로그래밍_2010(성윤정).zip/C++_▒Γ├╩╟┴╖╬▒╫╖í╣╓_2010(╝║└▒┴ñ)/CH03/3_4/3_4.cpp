#include<iostream>
using namespace std; 
void main( )
{
   int i=200;
   cout<<"  i�� 300�̳�? " ;
   if(i==300) 
      cout<<"true\n";
   else
      cout<<"false\n";
    
   cout<<"  i�� 300�̳�? " ;
   if(i=300)
      cout<<"true\n";
   else
      cout<<"false\n";
}