 #include <iostream>
 using namespace std;
 void main()
 {
   for(int dan=2;dan<=9;dan++)    // �ٱ� for��
     for(int j=1;j<10;j++) //���� for��
        cout << dan << " * " << j <<" = " << dan*j <<"\n";      
  }
