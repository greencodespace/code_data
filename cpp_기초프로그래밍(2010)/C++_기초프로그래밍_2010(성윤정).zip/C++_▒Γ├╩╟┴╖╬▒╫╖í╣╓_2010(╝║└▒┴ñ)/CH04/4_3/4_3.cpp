 #include<iostream>
 using namespace std;
  void sum(  )
  {
  	cout << "��\n a + b = ��" << a + b ;
  }
  void main( )
  {	
  	int a=10, b=20;   			
  	sum( );
  }
