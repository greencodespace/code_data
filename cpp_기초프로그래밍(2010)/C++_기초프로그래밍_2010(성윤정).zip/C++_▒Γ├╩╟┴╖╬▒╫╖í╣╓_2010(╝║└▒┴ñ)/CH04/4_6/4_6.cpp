  #include<iostream.h>
  #define PI 3.141592
  void main( )
  {
     int r = 5, area ;
     area = 5*5*PI;
     PI = 2.71;
     cout << "area = " <<area<< "\n";
  }
