  #define PI 3.141592
  double area(int r)
  {
    double area = r*r*PI;
   return area;
  }



