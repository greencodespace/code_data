 #include <iostream>
 using namespace std;
 #include "my.h"
 void main( )
 {
    int a;
    double res;
    a=5;
    res = area(a);
    cout << "area => "<< res << "\n";
    cout << "PI => " << PI << "\n";
 }


