 #include<iostream.h>
 long int power(register int x, register int n);
 
 void main( )
 {
    int a = 2, b = 5;
 
    cout<<a<< " ^ " <<b<<"  => "<<power(a, b)<<"\n";
 }
 long int power(register int x, register int n)
 {
    register int k;
    long int p=1;
    for(k =1; k<=n; k++)
       p*=x;   
   return p;
}
