 #include<iostream>
 using namespace std;
 void main( )
 {
	int a = 10;
	cout<<" a = "<<a<<endl;
	{
		int a = 20;
		cout<<" a = "<<a<<endl;
		{
			a+=20;
			cout<<" a = "<<a<<endl;
		}
		cout<<" a = "<<a<<endl;
	}
	cout<<" a = "<<a<<endl;
 }
