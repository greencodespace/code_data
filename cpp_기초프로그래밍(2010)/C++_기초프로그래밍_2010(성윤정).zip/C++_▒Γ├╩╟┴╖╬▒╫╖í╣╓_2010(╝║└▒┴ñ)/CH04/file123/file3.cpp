 #include<iostream>
 using namespace std;
 static int b=20;
 void sub2( )
 { 
	b+=100;
    cout<<"\n sub2�� b (file3.cpp) ==> " << b;
 }
