#include <iostream>
using namespace std;
void print(int x, int y, int z) 
{
  cout<<x<<"    "<<y<<"    "<<z<<endl;
}
void print(int x, int y)      
{
  cout<<x<<"    "<<y<<endl;
}
void print(int x)                
{
  cout<<x<<endl;
}
void  main( )
{
  print(10, 20, 30); 
  print(10, 20);     
  print(10);         
}
