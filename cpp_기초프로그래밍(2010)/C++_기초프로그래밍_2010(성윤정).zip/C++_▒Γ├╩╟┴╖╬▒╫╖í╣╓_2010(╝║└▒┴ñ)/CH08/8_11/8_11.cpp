#include<iostream>
using namespace std;
class  Complex 	
{
 private :
	int 	real;	
	int 	image;
 public :
    Complex( );
	void ShowComplex( ) const;
};

Complex::Complex( )
{
 real=5;
 image=20;
}

void Complex::ShowComplex( ) const
{
	cout<<"( " <<real  <<" + " <<image << "i )" <<endl ;
}

void main( )
{
	Complex  x(10, 20);		
 	x.ShowComplex( );
}

