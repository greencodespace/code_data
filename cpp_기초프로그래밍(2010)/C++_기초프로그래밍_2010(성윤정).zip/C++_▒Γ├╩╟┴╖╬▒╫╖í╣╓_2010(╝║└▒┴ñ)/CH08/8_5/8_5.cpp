#include<iostream>
using namespace std;
class  Complex 	
{
 private :
	int 	real;	
	int 	image;
 public :
	void SetComplex( )  const;
	void ShowComplex( ) const;
};

void Complex::SetComplex( ) const
{
   real=2;
   image=5;
}  

 
void Complex::ShowComplex( ) const
{
	cout<<"( " <<real  <<" + " <<image << "i )" <<endl ;
}
void main( )
{
	Complex  x;		

 	x.SetComplex( );			
 	x.ShowComplex( );
}

