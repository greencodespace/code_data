#include <iostream>
using namespace std;
void print(int x=0, int y=0, int z=0);
void  main( )
{
  print(10, 20, 30); 
  print(10, 20);     
  print(10);  
  print();  
}
void print(int x, int y, int z) 
{
  cout<<x<<"    "<<y<<"    "<<z<<endl;
}