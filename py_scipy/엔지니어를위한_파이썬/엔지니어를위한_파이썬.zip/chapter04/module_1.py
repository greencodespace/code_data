# 파일명 : module_1.py """
print("module_1 is imported.")
wgt = 60.5  # 초기체중 [kg]


def teacher(x):
    if x > 60:
        print("과다체중입니다")
    else:
        print("적정체중입니다")
