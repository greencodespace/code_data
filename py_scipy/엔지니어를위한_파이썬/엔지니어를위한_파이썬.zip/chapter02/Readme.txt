2장에서 다룬 로켓 시뮬레이션 프로그램에 대한 소스코드는
아래의 깃헙 저장소를 참조하기 바랍니다.

https://github.com/pyjbooks/PyRockSim.git

