from datahandler import *

#전체 학년 평균 : 50점
dh = DataHandler('class_2_3.xlsx', '2-3')
dh.get_evaluation(50)

