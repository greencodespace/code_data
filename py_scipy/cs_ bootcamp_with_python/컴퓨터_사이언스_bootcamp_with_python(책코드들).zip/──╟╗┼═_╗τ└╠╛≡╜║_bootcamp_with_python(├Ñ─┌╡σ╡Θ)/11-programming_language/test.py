def func(a, b):
    return a + b

a = 10
b = 20

c = func(a, b)
print(c)
