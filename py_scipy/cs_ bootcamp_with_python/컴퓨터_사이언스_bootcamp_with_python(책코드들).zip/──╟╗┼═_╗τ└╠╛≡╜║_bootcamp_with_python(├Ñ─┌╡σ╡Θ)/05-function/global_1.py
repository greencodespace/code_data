g_var = 10#1

def func():
    print("g_var = {}".format(g_var))
    
if __name__ == "__main__":
    func()
