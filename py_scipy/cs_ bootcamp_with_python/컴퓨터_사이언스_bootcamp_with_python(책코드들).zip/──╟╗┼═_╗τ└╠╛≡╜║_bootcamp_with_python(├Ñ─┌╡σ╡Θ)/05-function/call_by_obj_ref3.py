def func(li):
    li = ['I am your father', 2, 3, 4]#1

if __name__ == "__main__":
    li = [1, 2, 3, 4]
    func(li)
    print(li)
