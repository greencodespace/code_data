def func(li):
    li[0] = 'I am your father!'#1

if __name__ == "__main__":
    li = [1, 2, 3, 4]
    func(li)
    print(li)

